%% Máme dva balíčky karet, v prvním jsou pouze červené (8 různých karet) a v druhém pouze žaludy (také 8 různých karet). Z prvního balíčku vyberete 5 karet, z druhého 4 karty. Kolik existuje kombinací výběru karet?
nchoosek(8,5) * nchoosek(8,4)
%% 21:  učitel má 15 příkladů z pravděpodobnosti a 5 ze statiskiky náhodně zvolí 6 příkladů
nchoosek(20,6); %38760
% jaká je pravděpodonost, že ze 6 vybraných budou 2 ze statiskiky
(nchoosek(5,2)*nchoosek(15,4))/nchoosek(20,6); %0.3522
%% 22: Dle zadání příkladu 21 dokažte, že součet pravděpodobností přes všechny možné stavy (vybrán 0, 1 … 5 příkladů ze statistiky) bude roven 1.
pra = 0;
for i = 0:5
    pra = pra + ((nchoosek(5,i)*nchoosek(15,6-i))/nchoosek(20,6));
end
pra

%% 25: Kolika způsoby je možno na šachovnici s 64 poli vložit 5 věží tak, aby se vzájemně neovlivňovaly, tj. žádná neležela ve stejném sloupci a řádku.
(64*49*36*25*16)/factorial(5)

%% 28: Máte funkci y=(1+x)^28. Spočtěte koeficient u x^6, x^9 a x^12
% binomická věta
nchoosek(28,6)
nchoosek(28,9)
nchoosek(28,12)
