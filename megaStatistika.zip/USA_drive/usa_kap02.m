%% 3: Dřevěnou kostku o straně 5 cm natřeme na červeno a rozřežeme na krychle o hraně 1 cm. Určete pravděpodobnost, že vylosujete krychličku, která 
% a)	Nebude obarvena.   [0.216] 
27/125
% b)	Bude obarvena na jedné stěně.  [0.432]
(9*6)/125
% c)	Bude obarvena na dvou stěnách. [0.288]
36/125
% d)	Bude obarvena na třech stěnách.  [0.064]
8/125
%% 4: Máme 10 druhů minerálek. 6 je perlivých, zbývající neperlivé. Určete pravděpodobnost, že z náhodně vybraných 3 minerálek budou
% a) Všechny perlivé.   [0.167]
(nchoosek(6,3)*nchoosek(4,0))/nchoosek(10,3)
% b) Jedna perlivá, ostatní neperlivé. [0.300]
(nchoosek(6,1)*nchoosek(4,2))/nchoosek(10,3)
% c) Jaké jsou elementární jevy pokusu? [0 perlivých, 1 perlivá, 2 perlivé, 3 perlivé]
p0 = (nchoosek(6,0)*nchoosek(4,3))/nchoosek(10,3)
p1 = (nchoosek(6,1)*nchoosek(4,2))/nchoosek(10,3)
p2 = (nchoosek(6,2)*nchoosek(4,1))/nchoosek(10,3)
p3 = (nchoosek(6,3)*nchoosek(4,0))/nchoosek(10,3)

%% 5: Ve hře šťastných deset je v osudí 80 míčků, z nichž se losuje 20. Sázející vybere 10 čísel. Určete pravděpodobnost, že uhádne právě 0 až 10 čísel. 

arr = [];
for i = 0:10
    arr = [arr, (nchoosek(10,i)*nchoosek(70,20-i))/nchoosek(80,20)];
end
bar(arr)

%% 8: Jaká je pravděpodobnost, že mezi 3 mariášovými kartami náhodně vytažených z balíčku bude právě 1 eso?

((nchoosek(4,1)*nchoosek(28,2))/nchoosek(32,3))
