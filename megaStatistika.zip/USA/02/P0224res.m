clear all
clc

%ud�lejte si obr�zek geometrick� pravd�podobnost a dopo��tejte
%pravd�podobnosti jednotliv�ch jev�
%P KOhas KOsig = 3 %
%P KOhas OKsig = 2 %
%P OKhas KOsig = 5 %
%P OKhas OKsig = 90 %