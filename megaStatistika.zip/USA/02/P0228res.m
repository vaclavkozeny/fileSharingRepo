clear all
clc

%Bayesova v�ta
%prvni st�elec 0.3* 1/3
%druh� st�elec 0.5* 1/3
%t�et� st�elec 0.8* 1/3

p=(0.5*1/3)/(0.3*1/3+0.5*1/3+0.8*1/3)