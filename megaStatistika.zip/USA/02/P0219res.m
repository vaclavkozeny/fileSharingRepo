clear all
clc

%příklad na podmíněnou pravděpodobnost, doporučuji udělat si obrázek z
%geometrické pravděpodobnosti

%máme 2 jevy P(kuřák)=0.4     P(nekuřák)= ?
%podmíněnou pravděpodobnost že člověk má/nemá srdeční chorobu za předpokladu

%zjistíme se průniky 
    %P kuřák má srdeční chorobu 12%
    %P kuřák bez srdeční choroby 28 %
    %P nekuřák se srdeční chorobou 8 %
    %P nekuřák bez srdeční choroby 52 %

%Podmíněné pravděpodobnost
%a) 
Pa=0.12/0.4

%b)
Pb=0.08/0.6