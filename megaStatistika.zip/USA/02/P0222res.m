clear all
clc

%B vyrobí x, předpokládejme že například 1000 ks
%A vyrobí 3*x, tedy předopkládejme např. 3000 ks

%počet zmetků
%B= 0.002*x, tj 2 ks
%A= 0.01*3*x, tj. 30 ks

P=1-(2+30)/(1000+3000)

