clear all
clc

%dvakr�t nebude eso, jednou bude

%celkem karet   N=32
%vytahuji karet n=3
%po�et es       M=4
%vyberu es      m=1

%prvn� �len z 28 ne es vyb�r�m dv� karty
%druh� �len ze 4 es vyb�r�m jedno
%jmenovatel ze 32 karet vyb�r�m 3
P=(nchoosek(28,2)*nchoosek(4,1))/nchoosek(32,3)