clear all
clc

%pozor nelze koule zamíchat do jednoho osudí

%pravděpodobnost, že vyberu první urnu
P1=0.5
%pravděpodobnost, že vyberu druhou urnu
P2=0.5

%pravděpodobnost, že v první urně vyberu bílou
P1b=6/9;
%pravděpodobnost, že v druhé urně vyberu bílou
P2b=5/6;

%Pravděpodobnost
P=P1*P1b+P2*P2b