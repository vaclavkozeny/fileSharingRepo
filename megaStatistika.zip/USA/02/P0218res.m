clear all
clc

%nejsou nezávislé, protože A prunik B se nerovna P(A)*P(B)

%P(nastane jev A za podminky ze nastal jev B)= P(A prunik B)/P(B)
%P=0.1/0.5
%P=0.2