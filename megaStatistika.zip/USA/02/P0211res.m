clear all
clc

%plocha �tverce
S1=3*3;
%plocha kru�nice
S2=pi*1*1;
pomer=S2/S1
