clear all
clc

PA=0.3;
PB=0.2;
%jak� je pravd�podobnost, �e vyhraje b�ec B za podm�nky �e nevyhraje b�ec
%A
PAdoplnek=0.7;
vysledek=PB/PAdoplnek