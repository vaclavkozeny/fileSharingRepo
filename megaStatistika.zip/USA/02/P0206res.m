%první student může být v libovolné skupině, na něm to nezáleží

%druhý student musí být ve stejné skupině jako první.
%je celkem 19 pozic, kde může být. Ale pouze 4 volné pozice, kde je první
%student.

%pravděpodobnost je 4/19.