clear all
clc

%celkem 32 karet
Pzal=8/32;
Peso=4/32;

P=Pzal*Peso
