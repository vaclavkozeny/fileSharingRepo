clear all
clc

%jedn� se o permutace s opakov�n�m
delka=length('abeceda');
vysledek=1/(factorial(delka)/(factorial(2)*factorial(2)))
