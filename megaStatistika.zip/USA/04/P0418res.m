clear all
clc

%lambda=600 za hodinu, nebo jinak 10 za minutu
%t=1.5

pravd=1-poisscdf(30.5,10*1.5)

