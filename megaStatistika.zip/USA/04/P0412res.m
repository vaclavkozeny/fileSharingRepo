clear all
clc

%a)
vysl_a=hygepdf(8,32,16,10)

%b)
vysl_b=binopdf(8,10,0.5)