clear all
clc

p=1/13983816;

vysledek=binopdf(2,1000,p)