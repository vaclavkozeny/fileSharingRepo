clear all
clc

%prvnich sedm tahu
p= 8/32;

p1az7=binopdf(4,7,8/32);

%osmy tah 7
p8=1/8;

vysledek=p1az7*p8