clear all
clc

a=binopdf(5,10,0.5)
b=poisspdf(5,5)