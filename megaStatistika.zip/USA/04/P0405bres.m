clear all
clc

p=0.8;

vysledek_a=binopdf(3,5,0.8)
vysledek_b=1-binocdf(2.5,5,0.8)