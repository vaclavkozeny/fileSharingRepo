clear all
clc

%lambda=1.5 chyby na str�nku
vysledek_a=poisspdf(4,1.5)

vysledek_b=poisspdf(0,1.5)*1000
