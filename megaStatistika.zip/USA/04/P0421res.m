clear all
clc

a=hygepdf(2,49,6,6)
b=binopdf(2,6,6/49)
c=poisspdf(2,36/49)
