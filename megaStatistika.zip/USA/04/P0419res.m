clear all
clc

%lambda=240 za hodinu, nebo jinak 4 za minutu
%t=1.5
%pravděpodobnost spojení 0.99

pocet=poissinv(0.99,6)
