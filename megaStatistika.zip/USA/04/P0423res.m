clear all
clc

a=binopdf(25,100,0.2)

%lambda = 0.2
%t=100
b=poisspdf(25,20)