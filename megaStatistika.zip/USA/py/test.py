from statsmodels.stats.diagnostic import *
T  = [680, 720, 760, 790, 820, 850, 880, 920, 940, 960, 980, 990]
print(lilliefors(T,"exp"))