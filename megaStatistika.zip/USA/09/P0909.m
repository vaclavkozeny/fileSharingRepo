savefile='P0909.mat';

x=normrnd(13,5,200,1);
save(savefile,'x');