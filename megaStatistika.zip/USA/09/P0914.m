savefile='P0914.mat';

x=wblrnd(1000,1.5,1,100);
save(savefile,'x')