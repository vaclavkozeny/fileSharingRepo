clear all
clc

x=exprnd(10,1,2400);
savefile = 'P0918.mat'
save(savefile,'x')