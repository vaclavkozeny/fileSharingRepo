savefile='P0911.mat';

x=lognrnd(4,2,100,1)
save(savefile,'x')