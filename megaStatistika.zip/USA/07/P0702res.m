clear all
clc
clear all
clc

x=0.1:0.1:1;
y=10*x;
n=length(x);

strhod_x=mean(x)
strhod_y=mean(y)

rozpt_x=var(x)
rozpt_y=var(y)

smodch_x=std(x)
smodch_y=std(y)

sikmost_x=kurtosis(x)
sikmost_y=kurtosis(y)

spicatost_x=skewness(x)
spicatost_y=skewness(y)