clear all
clc

q01=norminv(0.01,10,sqrt(80))
q05=norminv(0.05,10,sqrt(80))
q10=norminv(0.10,10,sqrt(80))
q50=norminv(0.50,10,sqrt(80))
q90=norminv(0.90,10,sqrt(80))
q95=norminv(0.95,10,sqrt(80))
q99=norminv(0.99,10,sqrt(80))
pravd=normcdf(0,10,sqrt(80))