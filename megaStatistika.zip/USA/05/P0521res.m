clear all
clc

%otev�e data ulo�en� v souboru
x=importdata('P0521.mat');
a=wblfit(x)