clear all
clc

%mu=5
%sigma=2

vysledek_a=norminv(0.2,5,2)
vysledek_b=norminv(0.5,5,2)
%symetrick� kolem 0.5
vysledek_c=norminv(0.8,5,2)
vysledek_d=normcdf(3.5,5,2)
vysledek_e=normcdf(8,5,2)
vysledek_f=normcdf(6.5,5,2)