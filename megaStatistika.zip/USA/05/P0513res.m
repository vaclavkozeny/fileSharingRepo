clear all
clc

a=exprnd(2000,1,10);
mean(a)

b=exprnd(2000,1,100);
mean(b)

c=exprnd(2000,1,1000);
mean(c)
median(c)
