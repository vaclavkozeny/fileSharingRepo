savefile='P0521.mat';
x=normrnd(250,50,1000,1);
save(savefile,'x');