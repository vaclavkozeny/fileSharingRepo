clear all
clc

%dosadim do vzorce
EX=3*gamma(1+1/1.5)

wblcdf(2,3,1.5)