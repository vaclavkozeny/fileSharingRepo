clear all
clc

x=importdata('P0538.mat');
boxplot(x)