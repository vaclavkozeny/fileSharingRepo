clear all
clc

syms a b
[a,b]=solve((a+b)/2 == 1, (b-a)^2/12 == 3)