savefile='P0512.mat';
x=exprnd(500,1000,1);
save(savefile,'x');