savefile='P0521a.mat';
x=exprnd(250,100,1);
save(savefile,'x');