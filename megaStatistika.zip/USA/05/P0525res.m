clear all
clc

%st�edn� d�lka je 50 mm
%rozptyl je 0,49 mm^2, sm�rodatn� odchylka je 0.7 mm
%N(50, 0.7)

pravd=normcdf(51,50,0.7)-normcdf(49,50,0.7)