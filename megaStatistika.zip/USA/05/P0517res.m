clear all
clc

EX=3;
lambda=1/EX;
F=1-exp(-lambda*2)