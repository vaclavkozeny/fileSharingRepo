clear all
clc

x=unifrnd(0,1);
y=5*x+10