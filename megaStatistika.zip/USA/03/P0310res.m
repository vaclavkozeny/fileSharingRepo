clear all
clc

syms a b x;
y=1-exp(-(x*a)^b);
z=diff(y)


