clear all
clc

A=exprnd(1850,1,1000);
B=max(20,normrnd(1220,240,1,1000));

save P1009.mat A B

