clear all
clc

x=normrnd(850,210,1,200);
y=x+normrnd(160,80,1,200);

save P1008.mat x y

