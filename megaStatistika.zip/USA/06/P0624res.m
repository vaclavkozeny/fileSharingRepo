clear all
clc
pravd=1-chi2cdf(20,12)