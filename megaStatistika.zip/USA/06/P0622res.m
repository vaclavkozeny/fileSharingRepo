clear all
clc

%ch� kvadr�t rozd�len� s 10 stupni volnosti
kvant5=chi2inv(0.05,10)
kvant95=chi2inv(0.95,10)