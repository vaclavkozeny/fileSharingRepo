clear all
clc

%Studentovo rozd�len� s 10 stupni volnosti
kvant5=tinv(0.05,10)
kvant95=tinv(0.95,10)