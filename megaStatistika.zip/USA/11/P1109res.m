clear all
clc

x=[1,2,3,4,5,6,7,8,9,10]'; 
y=[1,2,3,1,2,3,1,2,3,1]'; 
z=[3,9,17,10,16,26,14,25,38,23]'; 

LM1=fitlm([x,y],z,'linear')
LM2=fitlm([x,y],z,'interactions')