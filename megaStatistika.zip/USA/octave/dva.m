%--------------------Klasická----------------------
%3--------------
% kostku (strana 5cm) natřeme na černo, rozřežeme na 1x1
% pravděpodobnso, že nebude 1x1 obarvena
(3^3)/(5^3);
% 0.2160
% bude obarvena na jedné straně
(6*9)/125;
% 0.4320
% bude obarvena na dvou stranách
36/125;
% 0.2880
% bude obarvena na 3 stranách
8/125;
% 0.064

%4-------------
% 10 druhů minerálek, 6 perlivých, 4 neperlivé, 3 vybereme
% pravděpodobnost že budou všechny perlivé
nchoosek(6,3)/nchoosek(10,3);
% z perlivých vybíráme 3, a celkem vybíráme 3
% 0.166
% 1 perlivé, 2 neperlivé
(nchoosek(6,1)*nchoosek(4,2))/nchoosek(10,3);
% z perlivých vybíráme 1, teda z neperlivých musime vybrat 2, celkem vybíráme 3
% 0.30

%5---------------
% 80 míčku, 20 losujeme, vybere se 10 čísel
% pravděpodobnost, že bude uhodnuto 0-10 čísel
prav = [];
for i=0 : 10
 prav = [prav, (nchoosek(10,i)*nchoosek(70,20-i))/nchoosek(80,20)];
end
%nchoosek(10, i)
  %To je počet způsobů, jak z tvých 10 tipovaných čísel vybrat i správných čísel (které se trefily do těch 20 losovaných)
%nchoosek(70, 20 - i)
  ##Tady přichází ten důležitý bod:
  ##Z 80 míčků 20 je výherních.
  ##Ty máš 10 tipů, z toho jsi právě i uhodl správně.
  ##Zbylých (20 − i) výherních čísel tedy muselo přijít z čísel, která jsi netipoval.
  ##Proto se ptáme: Kolik možností je vybrat těch zbývajících (20 − i) správných čísel z čísel, které jsi netipoval?
  ##Netipoval jsi (80 − 10) = 70 čísel → tedy nchoosek(70, 20 - i)

%6---------------
% 20 studentů, dělíme na 4 skupiny, jaká je šande že bude A a B spolu
4/19;
% 0.21
% (míst ve skupině - 1) / (lidi - 1)

%7----------------
% permutace s opakováním
1/(factorial(7)/(factorial(2)*factorial(2)));
%8----------------
% 32 karet, vybýráme 3, pravděpodobnost, že tam bude eso
(nchoosek(4,1)*nchoosek(28,2))/nchoosek(32,3);
% ze 4 es vybýráme 1
% zbylé dvě karty nemůžou být eso (28) a vybíráme 2
% celkem vybýráme 3 karty
%10---------------
% 3 bílé, 5 černých, 4 červené, nevracíme je zpět
% jaká je šance na červenou dříve než bílou
4/7;
% jaká je šance že z těch co nás zajímají vytáhnu červenou

%11----------------
% čtverec o délce 3 cm
% a v ně je kružnice o poloměru 1 cm
% jaká je šance že bude náhodný bod uvnitř obou
pi/9;
%0.3491
% plocha kružnice / plocha čtverce

%12---------------
% schúzka mezi 12 a 13
% přicházejí nádoně a čekají na sebe 15 minut
(1-(0.75^2))/1;
% plocha kolem diagonály (1- 2x(trojuhelník se stranou 0.75 - to je těch 15 minut))
%0.437

%13---------------
%???

%17---------------
% kuřáci, nekuřáci -> podmíněnná pravděpodobnost
0.12/0.4;
%0.30
0.08/0.6;
%0.133

%20---------------
% A 0.3, B 0.2
% pravděpodobnsot, že vyhraje B když A nevyhraje (doplněk k P(A))
% P(B,!A) = P(B)/1-P(A)
0.2/0.7
%0.2857

%21----------------
% (0.8, 0.1, 0.1) pravděpodobnosti zařazení do skupiny, pravděpodobnost provozuschopnsoti (0.8, 0.6, 0.3)
% násobí se pravděpodobnsot skupiny a pravděpodobnost provozuscopnsoti
% sčítá se pro jednotlivé skupiny
(0.8*0.8) + (0.6*0.1)+(0.3*0.1);
%0.73

%22----------------
% A vyrobí 3x více než B
% vady: A - 0.01, B - 0.002
% jaká je šance že náhodný výrebek není zmetek
% A vyrobí 3/4 výrobků a násobíme jeho šancí na vadu
% B vyrobí 1/4
% odečítáme od 1 protože chceme šanci že NENÍ
1-(0.75 * 0.01)-(0.25*0.002);
%0.992

%23----------------
% 8 černých, 5 bílích, nevracíme
% tady chceme šanci na druhej tah když je první nějak
% B2|B1
(4/12);
% B2|C1
(5/12);
% C2|B1
(8/12);
% C2|C1
(7/12);

%24----------------
% musí se nakreslit obrázek rozložení
%hasici, ale ne signalizace
0.02
% oba fungují
0.90

%25---------------
% obrázek

%26---------------
% A - 0.5, B - 0.3, C - 0.15
% B odstoupil
% jaká je šance C
% šance C když nebude B (doplněk)
(0.15)/(0.7)
%0.214

%27------------
% dvě urny a v nich kuličky (6b + 3c, 5b+1c), náhodně volíme urnu
% jaká je šance že první koule bude bílá
% šance na bílou v urně * šance na urnu + šance na bílou v druhé urně * šance na druhou urnu
((6/9)*0.5)+((5/6)*0.5)

%28------------
% 3 strelci (0.3,0.5,0.8) sance, jeden vystřelil a trefily
% jaká je pravděpodobnost že to byla dvojka

% šance dvojky / celková šance
celkova = (0.3*(1/3))+(0.5*(1/3))+(0.8*(1/3));
dvojka = 0.5*(1/3);

dvojka/celkova;
%0.3125

%29--------------


