clc
clear
%1--------------
% 100 g sacky
% povoleny odchylka 1.5 g

% H0: var <= 1.5^2
% HA: var > 1.5^2

data = load("./data/P0801.mat").x;
var(data);
[h,p,ci,stat] = vartest(data,2.25,"tail","right");
1-p;

% na hladnine 5% H0 nezamitame

%2----------------

% povoleny rozptyl 0.6

% H0: var <= 0.6
% HA: var > 0.6

data = [2.22, 3.54, 2.37, 1.66, 4.74, 4.82, 3.21, 5.44, 3.23, 4.79, 4.85, 4.05, 3.48, 3.89, 4.90, 5.37];

[h,p,ci,stat] = vartest(data,0.6,"tail","right");

% na hladine 5% H0 zamítáme, pval = 0.0037

%3---------------
n = 25;

% H0: sigma = 300
% HA: sigma != 300

% vyberova stredni hodnota x = 3118
% vyberova smerodatna odchylka s = 357
test = (357^2)/(300^2)*(n-1);
[chi2inv(0.025,n-1),test,chi2inv(0.975,n-1)];
p_value=chi2cdf(test,n-1);
p_value=2*min(p_value,1-p_value);

% na hladnine 5% H0 nezamitame

%5-----------------
Spotreba=[8.8, 8.9, 9.0, 8.7, 9.3, 9.0, 8.7, 8.8, 9.4, 8.6, 8.9];

% H0: spotreba = 8.8
% HA: spotreba != 8.8

[h,p,ci,stat] = ttest(Spotreba,8.8);

% na hladine 5% H0 nezamitame

% H0: rozptyl = 0.1
% HA: rozptyl != 0.1

[h,p,ci,stat] = vartest(Spotreba,0.1);

% na hladine 5% H0 nezamitame

%6------------------
% stredni doba do poruch 27400
% smerodatna odchylka 5400

% H0: mu = 30000
% HA: mu != 30000

n = 50;

test = (27000-30000)/5400 * sqrt(n);

[tinv(0.025,n-1),test,tinv(0.975,n-1)];

p_value = tcdf(test,n-1);
p_value = 2*min(p_value,1-p_value);

% na hladine 5% H0 zamitame
% pval = 2.6e-4

%7------------------
% parovy test
x=[35.0,36.0,36.3,36.8,37.2,37.6,38.3,39.1,39.3,39.6,39.8;
37.2,38.1,38.2,37.9,37.6,38.3,39.2,39.4,39.7,39.9,39.9];

data = x(2,:)-x(1,:);

% H0: mu1 = mu2
% HA: mu1 != mu2
[h,p,ci,stat] = ttest(data,0);
% hypozezu H0 na hladnine 5% zamitame
% pval = 2.3e-3

% H0: mu1 >= mu2
% HA: mu1 < mu2

[h,p,ci,stat] = ttest(data,0,"tail","right");
% na hladnine 5% H0 zamitame

%8------------------
% sign test
data=[-6,-3,-1,0,2,3,5,6,7,8,9,11,12,14,15,18,22,28,32,37,41];

% H0: median = 25
% HA: median != 25
[p,h] = signtest(data,25);

% na hladnine 5% zamitame H0
% pval 7.2e-3

%9------------------
% sign test
Spotreba=[8.8, 8.9, 9.0, 8.7, 9.3, 9.0, 8.7, 8.8, 9.4, 8.6, 8.9];

% H0: median = 8.8
% HA: median != 8.8

[p,h] = signtest(Spotreba,8.8);

% na hladnine 5% nezamitame H0
% pval 0.507

%13---------------
% Wilcoxn test
clear
x=[12, 15, 24, 32, 63, 69, 75, 87, 95, 121, 154, 159, 162, 187,191,201,212,218,223,241, 246, 249, 253,259, 263, 269, 273, 291, 312, 313, 318, 323, 352, 356, 361, 368, 369, 371, 395, 521, 523, 561,785,800,823,837,844, 954, 991, 1023];

mean(x);

% H0: median = 220
% HA: median != 220

[p,h,stat] = signrank(x,220);

% na hladnine 5% H0 zamitame
% pval 0.017

%14--------------
% test relativni cetnosti
% T = (p-pr)*sqrt(n)/sqrt(pr*(1-pr))

% H0: pi = 0.15
% HA: pi != 0.15
% alpha = 0.05

p = 82/1000;
pr = 0.15;
n = 1000;
T = (p-pr)*sqrt(n)/sqrt(pr*(1-pr));
p = 2*normcdf(T,0,1);

% na hladnine tvrzeni H0 zamitame
% pval 1.7e-9

%15------------
Tporuch=[80,160,240,320,400,560,720,800,900,960,1000];
cens = [zeros(1,10),1];
freq = [ones(1,10),40];

% H0: stredni doba do poruchy = 3000
% HA: stredni doba do poruchy != 3000
[par, io] = expfit(Tporuch,0.05, cens, freq);

% protze 3000 je v 95% odhahu H0 nezamitame

%16---------------
rano=[98.5, 98.6, 98.7, 98.7, 98.7, 98.8, 98.9, 99.2, 99.3, 99.3];
odpo=[98.1,98.2, 98.3, 98.4, 98.6, 98.7, 98.8, 98.9, 99.0, 99.0];

% H0: var1 = var2
% HA: var1 != var2

[h,p,ci,stat] = vartest2(odpo,rano);

% na hlanine 5% H0 nezamitame
% pval 0.71

%17------------------
x=[3,4,5,6,8,9,9,10,11,12,13,13,14,15,15,15,16,16,17];
y=[5,5,6,6,6,7,7,8,8,9,9,10,10,11,13,15];

% H0: var1 = var2
% HA: var1 != var2

[h,p,ci,stat] = vartest2(x,y);

% na hladine 5% H0 nezamitame
% pval 0.1

%19----------------
x=[35.0,36.0,36.3,36.8,37.2,37.6,38.3,39.1,39.3,39.6,39.8;
37.2,38.1,38.2,37.9,37.6,38.3,39.2,39.4,39.7,39.9,39.9];

% H0: mu1 = mu2
% HA: mu1 != mu2
% hladina 5%
% both

[h,p,ci,stat] = ttest2(x(1,:),x(2,:));

% na hladnine 5% H0 nezamitame
% pval 0.112

%20---------------
A = [62,54,55,60,53,58];
B = [52,56,50,49,51];

% H0: mu1 = mu2 -> stredni hodnota
% HA: mu1 != mu2
% both

[h,p,ci,stat] = ttest2(A,B);
% na hladnine 5% H0 zamitame
% pval 0.021

%21------------------
L = [2.8,2.0,3.2,1.9,2.5,2.6,1.7,4.1];
P = [2.5,2.1,3.0,2.1,2.4,2.4,1.9,3.8];
rozdil = L-P;
[h,p,ci,stat] = ttest(rozdil);
[h,p,ci,stat] = ttest2(L,P);

%22-----------------
x=[24,26,27,28,28,28,29,31,32,33];
y=[-21,-5,3,8,14,17,19,21,29,38,46,52,68];

% H0: var1 = var2
% HA: var1 != var2

[h,p,ci,stat] = vartest2(x,y);
% na hladnine 5% zamitame H0
% pval 2.7e-7

% H0: mu1 = mu2
% HA: mu1 != mu2

[h,p,ci,stat] = ttest2(x,y,"vartype","unequal"); %podle vartest2 se urcuje typ: equal (H0) / unequal (HA)
% na hladnine 5% H0 nezamitame
% pval 0.36

%23---------------
x=[12,14,16,18,19,19,21,23,25,27,31,35,39,42];
y=[15,18,21,24,27,29,32,35];

[h,p,ci,stat] = vartest2(x,y);
% rozptyl je schodny

% H0: median1 = median2
% HA: median1 != median2
%both

[p,h,stat] = ranksum(x,y);

% na hlanine 5% H0 nezamitame
% pval 0.707

%24-------------
% testovani relativni cetnosti
n1 = 1240;
p1 = 325/1240;

n2 = 741;
p2 = 287/741;

% T = (p1-p2)/sqrt((p1*(1-p1)/n1)+(p2*(1-p2)/n2))
%pval=2*min(normcdf(T,0,1),1-normcdf(T,0,1))

% H0: pi1 = pi2
% HA: pi1 != pi2
% both
% alpha 0.05

T = (p1-p2)/sqrt((p1*(1-p1)/n1)+(p2*(1-p2)/n2));
[normcdf(0.025,0,1),T,normcdf(0.975,0,1)];
pom=normcdf(T,0,1);
pval=2*min(pom,1-pom);

% na hladnine 5% H0 zamitame
% pval 9e-9

%25----------------
clear
x1=[18,19,19,19,20,21,21,22,22,23,23,24,24,24,25,25,25,26,26,26,27,28];
x2=[17,18,18,19,19,20,21,21,22,22,22,23,23,23,23,24,24,25,25,26,26,27,28,29] ;
x3=[16,17,18,18,18,19,20,20,20,20,21,21,21,22,23,23,23,24,25,26,27,27,28,28,29,31];
x4=[14,15,16,16,17,18,19,20,22,22,22,23,24,25,25,27,27,27,28,28,28,31,31,33,34];
s1(1:22)=1;
s2(1:24)=2;
s3(1:26)=3;
s4(1:25)=4;

% H0: vsechny rozptyly jsou stejne
% HA: jeden z rozptylu neni stejny

[p_b,stat] = vartestn([x1,x2,x3,x4]',[s1,s2,s3,s4]',"display","off");
[p_l,stat] = vartestn([x1,x2,x3,x4]',[s1,s2,s3,s4]',"display","off","testtype","LeveneQuadratic");

%26---------------
%ANOVA
clear
data = load("./data/P0826.mat").x;
%normplot(data)
d1 = data(1:100)';
d2 = data(101:200)';
d3 = data(201:300)';
d4 = data(301:400)';
d5 = data(401:500)';

g1(1:100) = 1;
g2(1:100) = 2;
g3(1:100) = 3;
g4(1:100) = 4;
g5(1:100) = 5;
[p_b,stat] = vartestn([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]',"display","off")
%[p,anovatab] = anova1([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]');

% na hladine 5% H0 nezamitame

%27--------------------
x1=[18,19,19,19,20,21,21,22,22,23,23,24,24,24,25,25,25,26,26,26,27,28];
x2=[17,18,18,19,19,20,21,21,22,22,22,23,23,23,23,24,24,25,25,26,26,27,28,29] ;
x3=[16,17,18,18,18,19,20,20,20,20,21,21,21,22,23,23,23,24,25,26,27,27,28,28,29,31];
x4=[14,15,16,16,17,18,19,20,22,22,22,23,24,25,25,27,27,27,28,28,28,31,31,33,34];
s1(1:22)=1;
s2(1:24)=2;
s3(1:26)=3;
s4(1:25)=4;

% H0: mediany jsou shodne
% HA: nejaka dvoje neni

%p = kruskalwallis([x1,x2,x3,x4]',[s1,s2,s3,s4]');

% na hladnine 5% H0 nezamitame
% pval 0.79

%28-------------
clear
data = load("./data/P0828.mat").x;
d1 = data(1:100)';
d2 = data(101:200)';
d3 = data(201:300)';
d4 = data(301:400)';
d5 = data(401:500)';

g1(1:100) = 1;
g2(1:100) = 2;
g3(1:100) = 3;
g4(1:100) = 4;
g5(1:100) = 5;

[p_b,stat] = vartestn([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]',"display","off");

% na hladnine 5% H0 nezamitame
% pval 0.071

%kdyz je shoda rozptylu prokazana pouzivame anova
[p,anovatab,stats] = anova1([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]');

% na hlanine 5% H0 zamitame
% pval 0.018

[comparison,means]=multcompare(stats);

%29--------------------
clear
clc
data = load("./data/P0829.mat").x;
d1 = data(1:100)';
d2 = data(101:200)';
d3 = data(201:300)';
d4 = data(301:400)';
d5 = data(401:500)';

g1(1:100) = 1;
g2(1:100) = 2;
g3(1:100) = 3;
g4(1:100) = 4;
g5(1:100) = 5;

[p_b,stat] = vartestn([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]',"display","off")

% na hladnine 5% H0 zamitame
% pval 8.6e-6

%kdyz zamitame shodu rozptylu tak je kruskalwallis
[p,kwtab,stats] = kruskalwallis([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]');

% na hlanine 5% H0 zamitame
% pval 6.8e-4

[comparison,means]=multcompare(stats);

%30---------------
clear
clc
data = load("./data/P0830.mat").x;
d1 = data(1:100)';
d2 = data(101:200)';
d3 = data(201:300)';
d4 = data(301:400)';
d5 = data(401:500)';

g1(1:100) = 1;
g2(1:100) = 2;
g3(1:100) = 3;
g4(1:100) = 4;
g5(1:100) = 5;

[p_b,stat] = vartestn([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]',"display","off")

% na hladnine 5% H0 zamitame
% pval 0

%kdyz zamitame shodu rozptylu tak je kruskalwallis
[p,kwtab,stats] = kruskalwallis([d1,d2,d3,d4,d5],[g1,g2,g3,g4,g5]');

% na hlanine 5% H0 zamitame
% pval 3.7e-3

[comparison,means]=multcompare(stats);
