%1-------------
% 50 hodu kostkou
vals = [1,2,3,4,5,6];
freq = [11,8,14,5,7,5];
% alpha 5%

% H0: p1-6 = 1/6
% HA: p1-6 != 1/6

[h,p,stat] = chi2gof(vals, 'expected',[50/6,50/6,50/6,50/6,50/6,50/6],'frequency',freq);

% na hladnie 5% H0 nezamitame
% pval 0.179

%2----------------

% asi se resi jiank kdyz to je cetnsot a pravdepodobnost ???
n = 50;
vals = [ones(1,15),2*ones(1,10),3*ones(1,10),4*ones(1,8),5*ones(1,7)];
% alpha 5%

% H0: vysledky jsou podle ocekavani
% HA: vysledky nejsou podle ocekavani

[h,p,stat] = chi2gof(vals, 'expected', [18,14,10,4.5,3.5]);

% na hladnine 5% H0 nezamitame
% pval 0.051

%3----------------

% taha se 6 ze 49
% 1000 sazeni
% 385 - 0
% 431 - 1
% 148 - 2
% 29 - 3
% 5 - 4
% 1 - 5
data = [zeros(1,385),ones(1,431),2*ones(1,148),3*ones(1,29),4*ones(1,5),5];
% alpha 5%

% H0: vysledky odpovidaji realite
% HA: vysledky neodpovidaji realite

% binopdf
B5=binopdf(5,6,6/49)*1000;
B4=binopdf(4,6,6/49)*1000;
B3=binopdf(3,6,6/49)*1000;
B2=binopdf(2,6,6/49)*1000;
B1=binopdf(1,6,6/49)*1000;
B0=binopdf(0,6,6/49)*1000;

%zjistime cetnosti a pak porovname s namerenyma datama

[h,p,stat] = chi2gof(data,'expected',[B0,B1,B2,B3,B4,B5]);

% na hladine 5% H0 zamitame
% pval 1e-4

%hygepdf
H5=hygepdf(5,49,6,6)*1000;
H4=hygepdf(4,49,6,6)*1000;
H3=hygepdf(3,49,6,6)*1000;
H2=hygepdf(2,49,6,6)*1000;
H1=hygepdf(1,49,6,6)*1000;
H0=hygepdf(0,49,6,6)*1000;

[h,p,stats]=chi2gof(data,'expected',[H0,H1,H2,H3,H4,H5]);

% na hladine 5% zamitame H0
% pval 4.1e-5

%4-------------
data0(1:3)=0;
data1(1:10)=1;
data2(1:15)=2;
data3(1:12)=3;
data4(1:17)=4;
data5(1:10)=5;
data6(1:10)=6;
data7(1:9)=7;
data8(1:5)=8;
data9(1:5)=9;
data10(1:4)=10;
data11(1:5)=11;

data = [data0,data1,data2,data3,data4,data5,data6,data7,data8,data9,data10,data11];

% H0: data jsou z poissonova rozdeleni
% HA: data nejsou z poissonova rozdeleni

[h,p,stat] = chi2gof(data, 'cdf', {@poisscdf,mean(data)});

% na hladnine 5% H0 zamitame
% pval 2.3e-5

%5---------------

data = poissrnd(10,1,100);
[h,p,stat] = chi2gof(data, 'cdf', {@poisscdf,mean(data)});
% data jsou z poissonova rozdeleni

data = [data, 14,15,17,18,19,21,22,24,26,27,27,28,32,34,36];
[h,p,stat] = chi2gof(data, 'cdf', {@poisscdf,mean(data)});
% data uz nejsou z poiss

%6--------------

% 10 cernych
% 20 bilich

% losujeme vzdy 5

% pocet bilich kouli v tazich
data=[0,1,0,1,0,2,0,1,1,0,0,1,0,1,0,2,0,1,1,0,0,0,0,1,2,1,1,2,1,0,1,2,1,2,3];

% H0: pochazeji z bino rozlozeni -> nepodvadi
% HA: nepochazeji z bino -> podvadi

% zase je to pres expected
E = [binocdf(0,5,2/3),binocdf(1,5,2/3),binocdf(2,5,2/3),binocdf(3,5,2/3),binocdf(4,5,2/3),binocdf(5,5,2/3)]*length(data);

[h,p,stat] = chi2gof(data, 'expected',E);

% na hladnine 5% H0 zamitame -> data nejsou z bino rozdeleni
% pval 0

%7--------------
clear
clc
data = xlsread("./data/P0907.xlsx");

% H0: data jsou z exp rozlozeni
% HA: data nejsou z exp

[h,p,stat] = chi2gof(data,'cdf',{@expcdf,mean(data)});
% na hladnie 5% H0 zamitame
% pval 0.046

wblplot(data);
param = wblfit(data);
[h,p,stat] = chi2gof(data,'cdf',{@wblcdf,param(1),param(2)});

% na hladine 5% zamitame H0
% pval 0.014

%9--------------
clear
data = load("./data/P0909.mat").x;

% H0: data jsou z norm
% HA: data nejsou z norm
normplot(data);
[mu,sigma] = normfit(data);
[h,p,stat] = chi2gof(data,'cdf',{@normcdf,mu,sigma});
% na hladine 5% nezamitame H0
% pval 0.639

% H0: norm(mu = 15, sigma^2 = 25) -> do normcdf vstupuje sqrt(sigma^2)
% HA: data nejsou z tohoto rozlozeni
[h,p,stat] = chi2gof(data,'cdf',{@normcdf,15,5});

% na hladine 5% H0 zamitame
% pval 2.7e-5

%10-----------------
clear
data = load("./data/P0910.mat").x;
mu = 20;
sigma2 = 100;

% H0: data pochazeji z norm(20,10)
% HA: data nepochazeji z norm(20,10)
[h,p,stat] = chi2gof(data,'cdf',{@normcdf,mu,sqrt(sigma2)});
% na hladine 5% zamitame H0
% pval 5.9e-7

% H0: data pochazeji z norm(20,10)
% HA: data nepochazeji z norm(20,10)
boxplot(data)
dolni = quantile(data,0.25)-1.5*iqr(data);
horni = quantile(data,0.75)+1.5*iqr(data);
data = data(data>dolni);
data = data(data<horni);
[h,p,stat] = chi2gof(data,'cdf',{@normcdf,mu,sqrt(sigma2)});
% na hladnie 5% zamitame H0
% pval 7.11e-3

%11----------------
clear
data = load("./data/P0911.mat").x;

% H0: data jsou z log-norm rozdeleni
% HA: data nejsou z log-norm rozdeleni
param = lognfit(data);
[h,p,stat] = chi2gof(data,'cdf',{@logncdf,param(1),param(2)});
% 0 df -> nelze pouzit
[h,p,stat] = chi2gof(data,'cdf',{@logncdf,param(1),param(2)},'edges',[0,10,50,100,200,500,1000,10000]);
% na hladine 5% H0 nezamitame

%13---------------

data = [normrnd(20,30,1,50),normrnd(30,10,1,50)];

% H0: data jsou z norm rozlozeni
% HA: data nejsou

[h,p,stat] = chi2gof(data,'cfd',{@normcdf,mean(data),var(data)});

% na hladnie 5% H0 nezamitame
% pval 0.129

%14-------------
clear
clc
data = load("./data/P0914.mat").x;

params = wblfit(data);

% H0: data jsou z weinluova rozdeleni
% HA: data nejsou z weibluova rozlozeni

[h,p,stat] = chi2gof(data,'cdf',{@wblcdf,params(1),params(2)});

% na hladine 5% H0 nezamitame
% pval 0.531

%15-------------
% KS test
vyska=[162,167,170,171,172,175,178,179,180,181,182,184,185,187,191,195];
%[h,p] = lillietest(vyska);
%normplot(vyska)

a(1:length(vyska),1)=vyska';
a(1:length(vyska),2)=normcdf(vyska',mean(vyska),std(vyska));
[h,p,stat,cv] = kstest(vyska,'cdf',a);

% na hladine 5% H0 nezamitame
% pval 0.996

%16-------------
t=[37,48,54,75,81,104,123,141,156,187,195,213,241,254,271,289,312,345,395,412,461,512,651,731];

% CFD do kstest
a(1:length(t),1)=t';
a(:,2)=expcdf(t,mean(t));

[h,p,ksstat,cv] = kstest(t,"cdf",a);
% na hladine 5% nezamitame H0
% pval 0.73

% wbl
param = wblfit(t);
a(1:length(t),1)=t';
a(:,2)=expcdf(t,param(1),param(2));
[h,p,ksstat,cv] = kstest(t,"cdf",a);

%16b--------------
t=[37,48,54,75,81,104,123,141,156,187,195,213,241,254,271,289,312,345,395,412,461,512,651,731];

% sem vstupuje 1/lambda

a(1:length(t),1)=t';
a(:,2)=expcdf(t,100);
[h,p,ksstat,cv] = kstest(t,"cdf",a);

a(:,2)=expcdf(t,200);
[h,p,ksstat,cv] = kstest(t,"cdf",a);

a(:,2)=expcdf(t,300);
[h,p,ksstat,cv] = kstest(t,"cdf",a);

a(:,2)=expcdf(t,500);
[h,p,ksstat,cv] = kstest(t,"cdf",a);

a(:,2)=expcdf(t,1000);
[h,p,ksstat,cv] = kstest(t,"cdf",a);

%17-----------------
clc
pade = rand(1,50);
sto = rand(1,100);

CDF50(:,1)=pade';
CDF50(:,2)=unifcdf(CDF50(:,1),0,1);

CDF100(:,1)=sto';
CDF100(:,2)=unifcdf(CDF100(:,1),0,1);

[h,p,ksstat,cv] = kstest(pade,"cdf",CDF50);
[h,p,ksstat,cv] = kstest(sto,"cdf",CDF100);


CDF50(:,1)=pade';
CDF50(:,2)=unifcdf(CDF50(:,1),0.2,1.2);

CDF100(:,1)=sto';
CDF100(:,2)=unifcdf(CDF100(:,1),0.2,1.2);

[h,p,ksstat,cv] = kstest(pade,"cdf",CDF50);
[h,p,ksstat,cv] = kstest(sto,"cdf",CDF100);

%18-----------
clear
clc
data = load("./data/P0918.mat").x;
normplot(data)

a(:,1)=data';
a(:,2)=normcdf(a(:,1),10,3);

[h,p,ksstat,cv] = kstest(data,"cdf",a);

% na hladine 5% zamitame H0 - data nesjou z norm rozdeleni

%19------------
t=[37,54,81,123,156,213,254,289,345,512,731];
% data jsou z norm rozdeleni
% pval 0.57

%20-------------
clear
% data se musi zlogaritmivat
t = [24,35,61,87,120,151,187,214,341,541,653,1213,2421];
t_l = log10(t);

param = lognfit(t);
a(:,1)=t';
a(:,2)=logncdf(a(:,1),param(1),param(2));
[h,p,ksstat,cv] = kstest(t,"cdf",a);

y=log10(t);
CDF(:,1)=y';
CDF(:,2)=normcdf(CDF(:,1),mean(y),std(y));
[h,p,ksstat,cv]=kstest(y,"cdf",CDF);

%22------------
clear
clc
% dvouvyberovy KS test
x=[3,5,9,12,15,17,21,24];
% normali rozlozeni
% pval 0.988
y=[5,8,12,12,15,17,19,24,25,28];
% normali rozlozeni
% pval 0.83

% H0: data jsou ze stejneho rozdeleni
% HA: data nejsou ze stejneho rozdeleni

[h,p,kstest] = kstest2(x,y);

% na hladine 5% nezamitame H0
% pval 0.985

%23------------
x=[31,36,42,48,52,57];
y=[15,18,22,27,29,34,35,38,43,49,52];

% H0: data jsou ze stejneho rozdeleni
% HA: data nejsou ze stejneho rozdeleni

[h,p,kstest] = kstest2(x,y)
% na hladine 5% nezamitame H0
% pval 0.26

%24------------
clear
clc
dvacetN = normrnd(0.5,0.25,1,20);
dvacetU = unifrnd(0,1,1,20);

% H0: data jsou ze stejneho rozdeleni
% HA: data nejsou ze stejneho rozdeleni

[h,p,kstest] = kstest2(dvacetN,dvacetU)
% na hladine 5% nezamitame H0
% pval 0.77

dvesteN = normrnd(0.5,0.25,1,200);
dvesteU = unifrnd(0,1,1,200);

% H0: data jsou ze stejneho rozdeleni
% HA: data nejsou ze stejneho rozdeleni

[h,p,kstest] = kstest2(dvesteN,dvesteU)
% na hladine 5% zamitame H0

%25----------
clear
clc

data = xlsread("./data/P0925.xlsx");
x = data(:,1);
y = data(:,2);

% H0: data jsou ze stejneho rozdeleni
% HA: data nejsou ze stejneho rozdeleni
[h,p,kstest] = kstest2(x,y)
% na hladine 5% zamitame H0
% pval 4.1e-11

%26----------------
clear
clc

Praha=[16,18,18,18,21,23,25,28,31,34,37,41,45,48,48,61];
Liberec=[13,14,14,15,15,16,17,18,23,28,34,36];

% H0: median Prahy je mensi nebo roven nez Lib
% HA: median Prahy je vetsi net Lib

% ranksum
% alpha 5%
% right

[p,h,stat] = ranksum(Praha,Liberec,"tail","right");
% na hladine 5% zamitame H0
% pval 3e-3

% H0: Liberec ma nizsi nebo rovnou dist funcki
% HA: Liberec ma vyssi dist fci

[h,p,kstest] = kstest2(Praha,Liberec,"tail","smaller");

