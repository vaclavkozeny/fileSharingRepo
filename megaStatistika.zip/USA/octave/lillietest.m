function [h, pval, ksstat] = lillietest(x, alpha, n_sim)
  % Lillieforsův test normality
  % x – vstupní data
  % alpha – hladina významnosti (např. 0.05)
  % n_sim – počet simulací (např. 1000)

  if nargin < 2
    alpha = 0.05;
  endif
  if nargin < 3
    n_sim = 1000;
  endif

  x = sort(x(:));
  n = length(x);
  mu = mean(x);
  sigma = std(x);
  z = (x - mu) / sigma;
  F_empirical = (1:n)' / n;
  F_theoretical = normcdf(z, 0, 1);
  ksstat = max(abs(F_empirical - F_theoretical));

  % Simulace D-statistiky pro náhodná normální data (Lilliefors correction)
  D_sim = zeros(n_sim, 1);
  for i = 1:n_sim
    r = randn(n, 1);
    r = (r - mean(r)) / std(r); % standardizace
    F_emp = (1:n)' / n;
    F_th = normcdf(sort(r));
    D_sim(i) = max(abs(F_emp - F_th));
  endfor

  % p-hodnota = podíl simulací s D >= D_observed
  pval = mean(D_sim >= ksstat);

  % rozhodnutí o zamítnutí H0
  h = pval < alpha;
endfunction
