%3-----------------
%balíčky mouky
data = [987, 1001, 993, 994, 993, 1005, 1007, 999, 995, 1002];

%95% stredni hodnota
[h,p,ci] = ttest(data)
%993.1 - 1002.06

%90% stredni hodnota
[h,p,ci] = ttest(data,1000,"alpha",0.1)
%993.98 - 1001.22

%95% minimum
[h,p,ci] = ttest(data,1000,"tail","right")
%993.98 - Inf

%4-----------------
prumer = 44; %s
odchylka = 4; %s
n = 12;
%90% interval delky operace
% podle vzorcu - nemame data
prumer - (odchylka/sqrt(n)*tinv(0.05,11))
prumer + (odchylka/sqrt(n)*tinv(0.05,11))
% 41.926 - 46.074

%5-------------------
n = 10;
data = [380, 402, 408, 412, 454, 459, 472, 481, 491, 502];

%normplot(data)

[h,p,ci] = ttest(data);
[h,p,ci] = ttest(data,450,"tail","left");
[h,p,ci] = ttest(data,450,"tail","right");

%6---------------------
%data o zakaznicich z obchodu
data=[541,574,585,596,612,618,632,641,654,671,681,692,711,713,718,719,754,796,812,815,835,858];
%normplot(data)
mean(data)
[h,p,ci] = ttest(data,692,"alpha",0.01)

%7---------------
prumer = 12.01;
smerOdchylka = 0.04;
n = 80;
% 95% interval stredni hodnoty
prumer - (smerOdchylka/sqrt(n)*tinv(0.025,n-1));
prumer + (smerOdchylka/sqrt(n)*tinv(0.025,n-1));
%12.003 - 12.019

%8-----------------
data  = [987, 1001, 993, 994, 993, 1005, 1007, 999, 995, 1002];
sigma = var(data);
[h,p,ci] = vartest(data,38);
sqrt(ci);
[h,p,ci] = vartest(data,38,"tail","left");

%9----------------
n = 100;
prumer = 150;
vyberRozptyl = 16;

((n-1)*vyberRozptyl)/chi2inv(0.025,n-1);
((n-1)*vyberRozptyl)/chi2inv(0.975,n-1);

prumer - (sqrt(vyberRozptyl)/sqrt(n)*tinv(0.025,n-1));
prumer + (sqrt(vyberRozptyl)/sqrt(n)*tinv(0.025,n-1));

%10---------------
% intervalovy odhad cetnosti - podle vzorce
% p pravdepodobnsot jevu
% n pocet respondentu

p = 0.12;
n = 400;
Ci=[p-sqrt(p*(1-p)/n)*norminv(0.025,0,1),p+sqrt(p*(1-p)/n)*norminv(0.025,0,1)];
n = 1600;
Ci=[p-sqrt(p*(1-p)/n)*norminv(0.025,0,1),p+sqrt(p*(1-p)/n)*norminv(0.025,0,1)];

%11--------------
% intervalovy odhad cetnosti - podle vzorce
% 320 vybrano
% 20 000 celkem
% 59 ma problem

p = 59/320;
n = 320;
% 95% podil konzerv s problemem
Ci=[p-sqrt(p*(1-p)/n)*norminv(0.025,0,1),p+sqrt(p*(1-p)/n)*norminv(0.025,0,1)]
% kolik to je konzerv
Ci*20000

%12-----------------
p = 0.2;
%syms n
%func = @(n) sqrt(p*(1-p)/n)*norminv(0.025,0,1) == 0.01
%solve(func)

%15--------------
x=[37,61,98,135,162,194,222,235,256,287,317,345,400,412,484,495,510,528,612,711,787,843,911,987,1014,1218,1512];
%normplot(x);
n = length(x);
[median(x)-1.57*iqr(x)/sqrt(n), median(x)+1.57*iqr(x)/sqrt(n)];

%16-----------------
x = normrnd(170,50,1,10000);
[h,p,ci] = ttest(x);
n = length(x);
[median(x)-1.57*iqr(x)/sqrt(n), median(x)+1.57*iqr(x)/sqrt(n)];

%16a---------------
Tporuch=[80,160,240,320,400,560,720,800,900,960,1000];
cens = [zeros(1,10),1];
freq = [ones(1,10),40];
[a,b] = expfit(Tporuch,0.05,cens,freq);

%16b--------------
data = load("./data/P0716b.mat").x;
[par,io] = wblfit(data);

%17-------------
x20=[3.96,4.03,4.07,4.12,4.16,4.18,4.20,4.22,4.23,4.24,4.24,4.25,4.29,4.32,4.35,4.38,4.41,4.44];
x50=[4.02,4.07,4.11,4.16,4.22,4.28,4.32,4.36,4.40,4.42,4.46,4.48,4.51,4.52,4.54,4.58,4.62,4.73];

var(x20)/var(x50);
%0.4141
% 99% odhad rozptylu
[h,p,ci] = vartest2(x20,x50,"alpha",0.01);
%ci 0.1117   1.5351

%18-------------------
% cesta vlakem v roce 1980 a 2015
t1980=[243,251,257,257,259,261,263,265,284, 293];
t2015=[191,193,193,195,195,195,197,198,199,202,202,203,204,205,207,208];

% 99% odhad zrychleni, nevim proc ale je tady equal
[h,p,ci] = ttest2(t1980,t2015,"alpha",0.01,"Vartype","equal");
% 52.818   75.407

%21----------------
clear
%20 kusu v krabici
% DISK 40 krabic - 24 vadnych
x1 = 24;
n1 = 800;
% EMEM 30 krabic - 14 vadnych
x2 = 14;
n2 = 600;

alfa = 0.95;

p1 = x1/n1;
p2 = x2/n2;
p = (x1+x2)/(n1+n2);
%vzorec
%Ci=[(p1-p2)-sqrt(p*(1-p)*(1/n1+1/n2))*norminv((1-alfa/2),0,1),(p1-p2)+sqrt(p*(1-p)*(1/n1+1/n2))*norminv((1-alfa/2),0,1)]
Ci=[(p1-p2)-sqrt(p*(1-p)*(1/n1+1/n2))*norminv(0.975,0,1),
(p1-p2)+sqrt(p*(1-p)*(1/n1+1/n2))*norminv(0.975,0,1)]

%22-----------------

% podpora v roce 2021
x1 = 57;
n1 = 541;

% podpora v roce 2020
x2 = 60;
n2 = 845;

% o kolik je vyssi podpora v roce 2021 nez 2020
p1 = x1/n1
p2 = x2/n2
p = (x1+x2)/(n1+n2)

Ci=[(p1-p2)-sqrt(p*(1-p)*(1/n1+1/n2))*norminv(0.975,0,1),
(p1-p2)+sqrt(p*(1-p)*(1/n1+1/n2))*norminv(0.975,0,1)]

%0.0044
%0.064


