%2 ----------------
factorial(20);
%4 ----------------
nchoosek(10,6);
%nchoosek(1000,600);
%6 ----------------
%zapoměl jsem dvě číslice tel. čísla. Vím, že jsou různá Jaká je pravděpododnot že vytočím správně?
(1/10)*(1/9);
%na kartách jsou čísla 1-5, otočím 3, jaká je pravděpodobnost že bude číslo sudé
%32 karet, 4 spodci, 4 filci. jaká je šance že vytáhnu filka nebo spodka
8/32;

%-------------------------------Variace,permutace---------------------------
%9 ----------------
%hraje 10 hráčů, kolika způsoby mohou obsadit první 4 místa
factorial(10)/factorial(6);
%5040
%10----------------
%5 hodů kostkou, kolik existuje kombinací čísel co napíšu
6^5;
%7776
%11----------------
%deset karet s číslem, vybereme 6, kolik je možností
factorial(10)/factorial(4);
%151200
%12----------------
%máme cifry (1,1,1,2,2,2,2,3,3,3,3,3), kolik 12místních čísel můžeme vytvořit
factorial(12)/(factorial(3)*factorial(4)*factorial(5));
%27720
%14---------------
%7 druhů pohledů, kolika způsoby lze nakoupit
%10 pohledů
nchoosek(16,10);
%5 pohledů
nchoosek(11,5);
%5 různých
nchoosek(7,5);
%[8008, 462, 21]
%15---------------
%8 přátel si vzájemně posílali pohlednice, kolik jich celkem rozeslali
8*7;
%16---------------
%12 mužstev, kolik se odehraje zápasů, každý s každým
6*11;
%--------------------------Kombinatorické pravidlo součinu--------------------
%17----------------
%3 hody kostkou
%šance na 3 šestky
(1/6)^3;
%šance na věechna čísla stejná
1*(1/6)^2;
%šance na 2 šestky a jiné číslo

%[0.0046, 0.0278, ???]
%18--------------
%2 balíčky (8 karet), první výběr 5, druhý 4. Kolik je možností
nchoosek(8,5)*nchoosek(8,4);
%3920
%19--------------
%32 karet, jaká je šance na 4 esa při výběru 4 karet
%s vracením
(4/32)^4;
%bez vracení
(4/32)*(3/31)*(2/30)*(1/29);
%[2.44e-4, 2.78e-5]
%20---------------
%10 příkladů, vybíráme 3, studenti znají 5 příkladů
%šance, že vybere ty co studenti znají
%příznivé příklady/všechny možnosti
nchoosek(5,3)/nchoosek(10,3);
%budou znát 2
%příznivé prípady*nepříznivé možnosti / všechny možnosti
nchoosek(5,2)*nchoosek(5,1)/nchoosek(10,3);
%[0.0833; 0.4167]
%21---------------
%15 příkladů ze pravďepodobnosi a 5 z statistiky
%nádodně zvolí 6, kolik existuje kombinací
nchoosek(20,6);
%právě dva ze statistiky
nchoosek(5,2)*nchoosek(15,4)/nchoosek(20,6);
%[38760; 0.3522]
%23--------------
%hodí se n kostkama, jaká je pravděpodobnost, že na všech bude stejné číslo
%(1/6)^(n-1) protože první číslo má šanci 1
%--------------------------------Sčítání pravděpodobností---------------------
%23---------------------
%32 karet, jaká je šance na to, že vyberu spodka, filka nebo žaludovou barvu
8/32 + 6/32 %protože žaludový spodek a filek už je obsažen v prvním čísle
%0.4375
%24-------------------
%Určete, že náhodné číslo mezi 100 a 1000 je:
%prime, dělitelné 2 nebo 3
143/900 + 450/900; %+ dělitelná 3 ale ne 2
%není prime
(900-143)/900
%ǰe dělitelné 2 nebo 5

%--------------------------Obecné příklady a opakování--------------------
%25---------------------
%kolika způsoby lze umístit 5 veží
64*(64-15)*(64-15-13)*(64-15-13-11)*(64-15-13-11-9)/factorial(5) %nezajímá nás pořadí proto /factorial(5)
%29--------------------
%15 chlapců a 10 dívek, kolik je možností na tým 5 a 5
nchoosek(15,5)*nchoosek(10,5)
%756756
