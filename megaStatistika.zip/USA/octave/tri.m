%3----------
syms t;
y = 1-exp(-t/3);
%fplot(y)

%5--------
data = load("../03/P0305.mat");
data = sort(data.x);
%plot(data);
%hist(data,50);

%6--------------

data = load("../03/P0306.mat").x;
counts = hist(data,6); %počet jendotlivých hodů
prob = counts / sum(counts);  %relativní četnost, teda šance na jedotlivé hodnoty
cdf = cumsum(prob);  %postupně sčítá jednotlivé hodnoty
% prob = [0.165, 0.168, 0.166, 0.167, 0.166, 0.168]
% tak cdf = [0.165, 0.333, 0.499, 0.666, 0.832, 1.000]
%stairs([0, 1:6], [0, cdf], 'linewidth', 2); %vykreslení do schodů

%10-------------
% Z distribuční funkce na hustotu pravděpodobnosti je derivace
syms x a b;
F = 1-exp(-(a*x)^b);
f = diff(F,x);
%11-------------
% z hustoty na distribuční funkci je integrace, pro vstup funkce (t) od 0 do t
clear
syms lambda t x;
f = lambda*exp(-lambda*t);
int(f,t,0,t);

%14------------
clear;
syms a x;
F = 1-exp(-a*x);
hustota = diff(F,x);
lambda = hustota/(1-F);
stredni_hodnota = int(x*hustota,x,0,inf);
% doplnění do vzorců z prezentace

%15--------------
clear
syms a b x
hustota = 1/(b-a)
stredni_hodnota = int(x*hustota,x,a,b)



