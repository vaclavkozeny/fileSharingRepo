%CLV
%1: zjistím střední hodnotu a rozptyl jedné náhodné veličiny
%2: oveřím parametry (n > 30)
%3:
  %součet mi = n*E(X) | sigma = n*D(X)
  %průměr mi = E(X) | sigma = D(X)/n
%4: pracuji s novým normálním rozdělením

%7------------------
data = unifrnd(0,1,1,1000);
[mu,sigma] = unifstat(0,1); %vraci sigma^2
sigma = sigma/1000;
sigma = sqrt(sigma);


normcdf(0.52,mu,sigma,"upper");

%8-------------------
% exponencialni rozlozeni
% mu = 5
% n = 100
mu = 5;
var = 25;

sigma = sqrt(var/100);

normcdf(4,mu,sigma);
%0.0227

%9---------------------
% 64 mist
% nesmi prekrocit 6000 kg
% stredni hodnota 90 kg
% smerodatna odchylka 10 kg
mu = 90;
var = 100; % 10^2

mu = 64*mu;
sigma = var*64;

normcdf(6000,mu,sqrt(sigma),"upper");
%0.0013

%10----------------------
mu = 3;
var = 4;
% 400 stranek
% P na mene nez 1000 chyb

mu = mu*400;
sigma = var*400;

normcdf(1000,mu,sqrt(sigma));
%2.8e-7

%11---------------------
% 100 hodu kostkou
mu = (1+2+3+4+5+6)/6;

%sigma^2 = E[X^2] - mu^2
%E[X^2] - prumer kvadratu
var = (1+4+9+16+25+36)/6 - mu^2;

mu = mu*100;
sigma = var*100;

normcdf(380,mu,sqrt(sigma))-normcdf(320,mu,sqrt(sigma));
%0.92

%12-------------------
% 600 hodu
% P ze 6 padne 105+
binocdf(104.5,600,1/6,"upper");
lambda = 1/6*600;
poisscdf(104.5,lambda,"upper");

[mu,var] = binostat(600,1/6);

normcdf(104.5,mu,sqrt(var),"upper");

%13------------------
% 16 bilich a 14 cernych
% 150 tazeni (vracime)

% P na prave 77 bilich

%bino
binopdf(77,150,16/30);

%poiss
lambda = 16/30*150;
poisspdf(77,lambda);

[mu,var] = binostat(150,16/30);

normpdf(77,mu,sqrt(var));

%14-------------------
% prumerny plat 27000
% smerodatna odchylka 8000

% nahlady 7000, s. odchylka 2000

% P ze zbyde 25000 po odecteni nakladu

normcdf(25000,20000,sqrt(8000^2 + 2000^2),"upper");

%15------------------
x2015=[587,124,651,1212,1074,523,273,800,485,961,1683,2411];
x2016=[121,524,2612,847,1310,1521,951,1000,521,12,190,263,321,587,953];

%17------------------
p = 0.168;
pi = 0.55;
n = 1000;
%z=(p-pi)/sqrt(pi*(1-pi)/n); proste to tak je, nejaky normovani
z=(p-pi)/sqrt(pi*(1-pi)/n);
prav = normcdf(z,0,1);

%18 a 19-------------------
p = 0.6;
pi = [0.45,0.5,0.55,0.59,0.6,0.61,0.65,0.7];
z = [];
n = 1000;
for i = 1:length(pi)
  z = [z, (p-pi(i))./sqrt(pi(i).*(1-pi(i))./n)];
end
prav = [];
z;
for i=1:length(z)
  prav = [prav, normcdf(z(i),0,1)];
end
prav;
z = [];
n = 100;
for i = 1:length(pi)
  z = [z, (p-pi(i))./sqrt(pi(i).*(1-pi(i))./n)];
end
prav = [];
z;
for i=1:length(z)
  prav = [prav, normcdf(z(i),0,1)];
end
prav;

%22------------------------
chi2inv(0.05,10);
chi2inv(0.95,10);
%23----------------------
df = [2,4,6];
x = 0:0.1:10;
for i=1:3
  y = chi2pdf(x,df(i));
  %plot(x,y, "DisplayName",num2str(df(i)))
  %hold on
  %legend show
end
%hold off
%24-----------------------
chi2cdf(20,12,"upper");

%25----------------------
df = [2,4,10,100];
P = [];
for i=1:length(df)
  P = [P, tcdf(1,df(i),"upper")];
end
P;
normcdf(1,0,1,"upper");

%26----------------------
tinv(0.05,10);
tinv(0.95,10);

%27--------------------
finv(0.05,10,5)
finv(0.95,10,5)
finv(0.05,5,10)
finv(0.95,5,10)

