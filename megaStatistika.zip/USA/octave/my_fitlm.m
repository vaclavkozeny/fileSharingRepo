function result = my_fitlm(X, z, alpha = 0.05)
    % Kontrola vstupů
    if rows(X) != rows(z)
        error("X a z musí mít stejný počet řádků.");
    endif

    n = rows(X);
    p = columns(X);

    % Regresní koeficienty
    theta = X \ z;
    z_pred = X * theta;
    residuals = z - z_pred;

    % Sum of squares
    SST = sum((z - mean(z)).^2);
    SSR = sum((residuals).^2);
    SSE = SST - SSR;

    % R-squared
    R2 = SSE / SST;

    % Střední kvadráty
    MSE = SSR / (n - p);
    MSR = SSE / (p - 1);

    % F-statistika a p-hodnota modelu
    F = MSR / MSE;
    pF = 1 - fcdf(F, p - 1, n - p);

    % Standardní chyby, t-statistiky, p-hodnoty a CI
    covB = MSE * inv(X' * X);
    SE = sqrt(diag(covB));
    t_stat = theta ./ SE;
    p_val = 2 * (1 - tcdf(abs(t_stat), n - p));
    t_crit = tinv(1 - alpha/2, n - p);
    CI_lower = theta - t_crit * SE;
    CI_upper = theta + t_crit * SE;

    % Výpis jako tabulka do konzole
    printf("\n  Coef     Estimate    SE        t       p-value    CI_Low    CI_High\n");
    printf("------------------------------------------------------------------------\n");
    for i = 1:p
        printf("  β%-2d     %9.4f  %7.4f  %7.2f    %7.4f   %7.4f   %7.4f\n", ...
               i - 1, theta(i), SE(i), t_stat(i), p_val(i), CI_lower(i), CI_upper(i));
    endfor

    printf("\nModel fit:\n");
    printf("  R² = %.4f\n", R2);
    printf("  F(%d, %d) = %.4f, p = %.4f\n", p - 1, n - p, F, pF);

    % Vrácení do struktury
    result.coefficients = theta;
    result.SE = SE;
    result.t = t_stat;
    result.p = p_val;
    result.CI_lower = CI_lower;
    result.CI_upper = CI_upper;
    result.R2 = R2;
    result.F = F;
    result.pF = pF;
    result.residuals = residuals;
end

