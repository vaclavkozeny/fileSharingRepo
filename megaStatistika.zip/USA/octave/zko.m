clear
clc
%1.
x=[52,54,55,56,57,58,58,59,59,60,61,62,62,63,64,64,64,65,66,67,68,68,69,72,73,75,77,79,82,85,87,89,92,95,131,168,195];
%3.
T  = [680, 720, 760, 790, 820, 850, 880, 920, 940, 960, 980, 990];
%4.
B = [148,175,312,354,387,412,423,454,485,521];
A = [310,361,629,718,781,828,851,911,979,1052];

%1-----------------------
xdolni = quantile(x,0.25) - 1.5*iqr(x);
xhorni = quantile(x,0.75) + 1.5*iqr(x);

x = x(x > xdolni);
x = x(x < xhorni);

%[h,p] = lillietest(x)
% pval 0.046 -> data nejsou z norm rolzozeni

% H0: x je z normalino rozlozeni
% HA: x neni z normalniho rozlozeni

a(:,1) = x';
a(:,2) = normcdf(a(:,1),60,10);

[h_norm,p_norm,ksstat, cv] = kstest(x,'cdf',a)

% na hladine 5% H0 zamitame
% pval 9.6586e-03 -> data nejsou z norm(60,10)

data = normrnd(60,10,1,50);

% H0: dist fce x = dist fce data
% HA: neni tomu tak

[h_stejne,p_stejne,kstest_stejne] = kstest2(x,data)
% nelze urcit presne, protoze se pri kazdem spusteni data generuji jinak

% H0: sigma x = 20
% HA: sigma x != 20

clear a
a(:,1) = x';
a(:,2) = normcdf(a(:,1),60,20);

[h_20,p_20,ksstat, cv] = kstest(x,'cdf',a)

% na hladine 5% zamitame H0
% pval 2.7e-4

%2-----------------------
n = 108;
% tahame 12

P_4esa = hygepdf(4,n,12,8)
% 4.67e-3

P_2az10 = hygepdf(12,n,8*9,12)
% 5.5e-3

%3--------------------
%12 se porouchalo
%8 ne

% parametry wbl
casy = [T,1000];
freq = [ones(1,12),8];
cens = [zeros(1,12),1];

[PARAMHAT, PARAMCI] = wblfit (casy, 0.05, cens, freq)
% 1010 7.67
% jsou data z exp rozlozeni

%muze byt beta 2

% H0: beta = 2
% HA: beta != 2

clear a
a(:,1)=T';
a(:,2)=wblcdf(T,1010,2);

[h_2,p_2,ksstat,cv] = kstest(T,"cdf",a)
% na hladine 5% zamitame
% pval 0.043

% H0: data jsou z exp
% HA: data nejsou z exp
clear a
a(:,1)=T';
a(:,2)=expcdf(T,mean(T));

[h_exp,p_exp,ksstat,cv] = kstest(T,"cdf",a)

% na hladine 5% zamizame H0
% pval 6.6584e-04

%4---------------------

%5---------------------
n1 = 1234;
p1 = 0.0862;

n2 = 1141;
x2 = 41;
p2 = x2/n2;

% H0: obliba je stejna
% HA: obliba neni stejna

T=(p1-p2)/sqrt((p1*(1-p1)/n1)+(p2*(1-p2)/n2));
pval=2*min(normcdf(T,0,1),1-normcdf(T,0,1))
% na hladine 5% H0 zamitame
% pval 2.2276e-07

