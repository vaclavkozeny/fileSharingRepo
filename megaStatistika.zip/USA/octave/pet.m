%12-------------
% vypoctete parametry exp rozlozeni
data = load("./data/P0512.mat").x;
mu = expfit(data);
lambda = 1/mu;

%13-------------
% vygeneruj cisla exp rozdeleni s mu = 2000
deset = exprnd(2000,1,10);
sto = exprnd(2000,1,100);
tisic = exprnd(2000,1,1000);
%stredni hodnota
mean(deset);
%rozptyl
var(deset);

mean(sto);
var(sto);

mean(tisic);
var(tisic);
%median
median(tisic);

%15---------------
% urcete stredni dobu opravy, pokud za 60 minut je opraveno 0.3 výrobku

syms l;
func = 1-exp(-60*l)==0.3;
% vzorec pravdepodobnostni fce, dosadime a vyresime
solve(func);
%0.0059
%168.2

%17---------------
% stredni doba do poruchy (mu) je 3 roky
% P ze se poroucha v prvnich 2 letech

expcdf(2,3);
%0.486

%17a--------------
data = xlsread("./data/P0517a.xlsx");
mu = expfit(data);
%5953
expcdf(10000,mu);
%0.813
%poiss na parvdepodobnsot 2 poruch za rok
poisspdf(2,(1/mu)*8640);
%0.246

%17b-------------
data = xlsread("./data/P0517b.xlsx");
mu = expfit([data',10000],0.05, [zeros(1,79), 1], [ones(1,79),21]);
%6353
%20---------------
% weiblovo rozdeleni
alpha = 3;
beta = 1.5;

% stredni hodnota
[m,v] = wblstat(alpha, beta);
wblcdf(2,alpha,beta);
%0.419

%21---------------
data = load("./data/P0521.mat").x;
wblfit(data);
%269.4 5.46

%21b---------------
data = xlsread("./data/P0521b.xlsx");
wblfit([data',10000],0.05,[zeros(1,79), 1], [ones(1,79),21]);
%6336 0.953

%24---------------
% normalni rozdeleni
mu = 5;
sigma = 2;

kvantil20 = norminv(0.2,mu,sigma);
kvantil50 = mu;
kvantil80 = norminv(0.8,mu,sigma);
x35 = normcdf(3.5,mu,sigma);
x8 = normcdf(8,mu,sigma);
x65 = 1-x35;

%25---------------
mu = 50
sigma = sqrt(0.49)

% rozmer mezi 49 a 51
mezi4951 = normcdf(51,mu,sigma) - normcdf(49,mu,sigma)
%0.846

%26---------------
sigma = 3

% chyba mezi -2 a 5
chyba25 = normcdf(5,0,sigma) - normcdf(-2,0,sigma)
%0.699

%3 vyrobky, P ze alespon u jendoho bude chyba mimo
% doplnek k tomu ze budou vsechny v intervalu
alespon1mimo = 1 - (0.7)^3 % sance ze budou vsechny je 0.7 * 0.7 * 0.7 -> proto na 3
%0.657

%30---------------
mu = 10;
sigma = sqrt(20);

tri = normcdf(3,mu,sigma);
cislo = tri + 0.25;
hledaneX = norminv(cislo,mu,sigma)
%7.766

%32----------------
hodnoty = [1, 5, 10, 50, 90, 95, 99];
pravdepodobnostni = [];
for i = 1:7
  pravdepodobnostni = [pravdepodobnostni, norminv(hodnoty(i)/100,10,sqrt(80))];
end
pravdepodobnostni;
% -10.8075   -4.7120   -1.4625   10.0000   21.4625   24.7120   30.8075
mensiNez0 = normcdf(0,10,sqrt(80));
%0.131

%33-----------------
data = load("./data/P0533.mat").x;
%boxplot(data); %abych nasel odlehla data staci boxplot :skull:
sort(data);
data = data(1:length(data)-4);
[mu,sigma] = normfit(data);

%34----------------
mu = 180;
sigma = sqrt(400);

jeden = normcdf(200,mu,sigma,"upper")
binocdf(2,5,jeden,"upper")
%0.031

%36-----------------
% logn
mu = 3;
sigma = 4;

% P ze je X mezi 2 a 4
P24 = logncdf(4,mu,sigma) - logncdf(2,mu,sigma)
%0.0612

x = 0:0.01:5;
y = (1./(x.*sigma.*sqrt(2.*pi)).*(exp((-(log(x)-mu).^2)./2.*sigma.^2)));
plot(y,x)
