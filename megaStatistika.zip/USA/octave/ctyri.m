%5---------------
% 5 hodíme mincí
% přavděpodobnost, že padne orel právě 2x
orel2 = binopdf(2,5,0.5);
%0.3125
% pravděpodobnsot, že padne orel alespoň 4
% teda že padne 0 nebo 1 panna
orel4 = binocdf(1,5,0.5);

%5a-------------
% šance na výhru ve sportce je 1/13983816
% sázím 1000
% jaká je šance, že vyhraju právě 2x
sportka = binopdf(2,1000,1/13983816);
%2.554 -9
%5b-------------
% šance na kvalitní 0.8
% tahám 5
% jaká je šance, že budou právě 3 kvalitní
prave3 = binopdf(3,5,0.8);
%0.204
% alespon 3 budou kvalitní
alespon3 = binocdf(2.5,5,0.8,"upper");
%0.942
%6--------------
% pravděpodobnost díkvy je 0.49
% celkem 25 dětí
% pravděpodobnost právě 10 divek
prave10 = binopdf(10,25,0.49);
%0.107
% alespon 10 a vice divek
alespon10 = binocdf(9.5,25,0.49,"upper");
%0.864
% vice nez 15 divek
vice15 = binocdf(15.5,25,0.49,"upper");
%0.096
% kolik jich bude nepravdepodbneji
vysledky = [];
for i=0:25
  vysledky = [vysledky, binopdf(i,25,0.49)];
end
[_,index] = max(vysledky);
%13 ale to je spatne

%7--------------
% chlapec 0.51
% kolik je minimální počet aby tam byl chlapec na 0.99
vysledky = [];
for i=1:10
 vysledky(i) = binocdf(0.5,i,0.51,"upper");
end
vysledky;
%7

%8---------------
% 0.1 vydnych vyrobku
% vybirame nahodne 20
% pravdepodobnost 0 vadných
vadny0 = binopdf(0,20,0.1);
%0.1216
% vice nez 5 vadnych
vadny5 = binocdf(5,20,0.1,"upper");
%0.0112


%8a---------------

%-------------------hyge-------------------------
%10----------
% 32 karet
% 3 losujeme
% pravdepodobnost na 2 esa

hygepdf(2,32,4,3); %pdf protože chceme právě 2
%0.033

% vracíme
binopdf(2,3,4/32);
%0.041

%11---------
clear
% 200 cisel
% 30 losujeme
% vybirame nahodne 10

% pravdepodobnost na prave 5 spravne
%hyge
prave5hyge = hygepdf(5,200,10,30);
%bino
prave5bino = binopdf(5,10,30/200);
%kolik nejpravdepodobneji uhodnu ciesl
vysledky = [];
for i=0:10
  vysledky = [vysledky, hygepdf(i,200,10,30)];
end
[_,index] = max(vysledky);
%plot(0:10,vysledky)
%nejpravdepodobneji uhodnu 1 cislo

%12-------------
% 32 karet
% 10 tahame
% pravdepodobnost ze tam bude 8 vyssich karet (eso, spodek, svrsek, filek)
%hyge
presne8hyge = hygepdf(8,32,16,10);
%0.023
%bino
presne8bino = binopdf(8,10,0.5);
%0.043

%12a------------
% 10000 b
% 7000 c
% losujeme 30
%hyge
prave22hyge = hygepdf(22,17000,10000,30);
%0.04118
%bino
prave22bino = binopdf(22,30,10000/17000);
%0.04111

%moc vzorků aby to že odebereme 22 něco změnilo

%13--------------
% hazi se kostkou
% pravdepodobnost ze 6 padne poprve u 5 hodu
geopdf(4,1/6);
%0.0803
%14--------------

%15--------------
% prodava knihu
% 0.1 ji koupi
% pravdepodobnost ze bude uspesny:
% prave u 5 zakaznika
prave5 = geopdf(4,0.1) % 4 neuspechy
% do 5 zakaznika
do5 = geocdf(3,0.1) % 3 neuspechy, 4 proda a 5 se neuvazuje
% pri 8 a vyssim zakaznikovi
vice8 = geocdf(6,0.1,"upper") %myslim ze tady ma bejt 7

%15a-------------
% negativně binomické rozdělení
prave10 = nbinpdf(7,3,0.35)
% neuspechy, uspechy, sance na uspechy
vice9 = nbincdf(6,3,0.35,"upper")
mezi610 = nbincdf(7,3,0.35) - nbincdf(2,3,0.35)
% mensi nez 10 - mensi nez 6 -> mezi 6 a 10

%15b--------------
% multinomické rozdělení
% 32 karet
% losujeme 10
% P na 8 vyssich karet
binopdf(8,10,0.5)
%0.043
% P na 2 esa, 3 krale, 2 filky a 1 spodek
y = mnpdf([2,3,2,1,2],[1/8,1/8,1/8,1/8,0.5])
% součet P musí dát 1
% musíme doplnit do počtu který taháme
%0.0012

%nevracíme
hygepdf(8,32,16,10)
%0.023
% podle vzorce

%16---------------
% na 100 metru latky je 10 kazu
% vybirame 20 metru

% P na 0 kazu
lambda = 2; % 10/100 * 20 metru
poisspdf(0,lambda)
%0.1353

% P na prave 2 kazy
poisspdf(2,lambda)
%0.270

% P na vice nez 5 kazu
poisscdf(5.5,lambda,"upper")
%0.016

%17---------------
% za 1 rok bylo na 10 strojich 5 poruch

% 5/10 za rok pro 1 strojich
% mame 2 roky a 25 stroju
lambda = 0.5 * 2 * 25;

% P pro 25 stroju po dobu 2 roky
poisscdf(11.5,lambda)
%0.0014

% P prave 20 poruch
poisspdf(20,lambda)
%0.0519

% P pro vice nez 25
poisscdf(25.5, lambda, "upper")
%0.447

%18----------------
% prumerny hovor trva 1.5m
% 600 hovoru za hodinu -> 10 za minutu

lambda = 1.5 * 10 % prumerna delka * pocet za minutu

% P ze bude soucasne vice nez 30 hovoru
poisscdf(30,lambda,"upper")
%1.9e-4

%19--------------
% prumerny hovor trva 1.5m
% 240 hovoru za hodinu -> 4 za minutu
% P ztraty nesmi preskocit 0.01

% kolik musi mit operator linek

poissinv(0.99,1.5*4) %lambda: prumerna delka * pocet za minutu
%12

%20--------------

% 1000 hodu minci
% P ze orel padne 480x - 520x

%bino
binocdf(520,1000,0.5)-binocdf(479, 1000, 0.5)
%0.805

%poiss
lambda = 0.5*1000 %pravdepodobnost * pocet hodu
poisscdf(520,lambda) - poisscdf(479,lambda)
%0.640

%21--------------
% tahne se 6 cisel ze 49
% sazime 6
% P ze uhodneme prave 2

%hyge
hygepdf(2,49,6,6)
%0.132

%aprox bino
binopdf(2,6,6/49)
%0.133

%aprox poiss
lambda = 1/49 * 6 * 6 %sance na uhodnuti * pocet hadanych cisel * pocet tahanych cisel
poisspdf(2,lambda)
%0.129

%22---------------
% na 1000 textu bylo 1500 chyb
% P ze na nahdone strance budou prave 4 chyby
lambda = 1500/1000
poisspdf(4,lambda)
%0.047
% kolik stran bude bez chyb
poisspdf(0,lambda)*1000
%223

%23--------------
% urednik zjistil, ze u 0.2 navrhu na pujcku je zamlcena informace
% P ze mezi 100 je bude 25 se zamlcenimi informacemi

%bino
binopdf(25,100,0.2)
%0.043

%aprox poiss
lambda = 0.2*100
poisspdf(25,lambda)
%0.044

%24----------------
% 0.5 je zamlceno
% P ze v 10 bude 5 zamlceni

%bino
binopdf(5,10,0.5)
%0.246

%aprox poiss
lambda = 0.5 * 10
poisspdf(5,lambda)
%0.175

%nebyl splnen ani jeden predpoklad

