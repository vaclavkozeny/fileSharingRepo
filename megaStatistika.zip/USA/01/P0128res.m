clear all
clc

%výpočet dle binomické věty
a=nchoosek(28,6)
b=nchoosek(28,9)
c=nchoosek(28,12)