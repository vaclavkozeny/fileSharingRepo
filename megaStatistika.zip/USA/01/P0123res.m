clear all
clc

%na prvnim hodu nezalezi, ostatni hody musi mit stejn� v�sledek
%vysledek je P=(1/6)^(n-1)