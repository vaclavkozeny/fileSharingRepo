clear all
clc

karet = 32;
spodku = 4;
filku = 4;

Puspechu=(spodku+filku)/32